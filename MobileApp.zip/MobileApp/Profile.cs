﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Versioning;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace MobileApp
{
    class Profile : Activity
    {
        public string dname;
        public string demail;
        public string pName { get { return dname; } set { dname = value; } }
        public string pemail { get { return demail; } set { demail = value; } }
        private TextView prname;
        private TextView premail;
        protected override void OnCreate(Bundle savedInstanceState)
        {
            prname = (TextView)FindViewById(Resource.layout.Id.dpname) ;
            prname.SetText = dname;
            premail = (TextView)FindViewById(Resource.layout.Id.dpemail);
            premail.SetText = demail;
            SetContentView(Resource.Layout.Profile);

        }
    }
}