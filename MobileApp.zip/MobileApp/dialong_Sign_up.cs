﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;

using Android.App;
using Android.Content;
using Android.Gestures;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Java.Lang;

namespace MobileApp
{
    public class LoginONEvent: EventArgs
    {
        private string mName;
        private string mPassword;
        private string memail;
        public string Name
        {
            get { return mName; }
            set { mName = value; }
        }
        public string Password
        {
            get { return mPassword; }
            set { mPassword = value; }
        }
        public string email
        {
            get { return memail; }
            set { memail = value; }
        }
        public onsignupEventArgs(string Nam,string Pass,string em) : base()
        {
            Name = Nam;
            Password = Pass;
            email = em;
        }

        private void Void()
        {
            throw new NotImplementedException();
        }
    }
    class dialong_Sign_up : DialogFragment
    {
        private EditText editName;
        private EditText editEmail;
        private EditText editPassword;
        private Button Signup;
        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
           base.OnCreateView(inflater, container, savedInstanceState);
            var view = inflater.Inflate(Resource.dialong_Sign_up.container, false);
            editName = EditText.FindViewsById(Resource.Id.Name);
            editEmail = view.FindViewsById<EditText>(Resource.Id.Email);
            editPassword = view.FindViewsById<EditText>(Resource.Id.Password);
            Signup = view.FindViewsById<Button>(Resource.Id.LoginButton);
            Signup.Click += mBtnClick_Click;
            return view;

        }
        private event EventHandler<onsignupEventArgs> SignupFinish;
        void mBtnClick_Click(object sender, EventArgs e)
        {
            SignupFinish.Invoke(this, new onsignupEventArgs(editName,editPassword,editEmail));
            this.Dismiss();
        }
        internal static void Show()
        {
            throw new NotImplementedException();
        }
    }
}