﻿using Android.App;
using Android.OS;
using Android.Support.V7.App;
using Android.Runtime;
using Android.Widget;
using Android.Views;
using Android.Webkit;

using System.Collections.Generic;
using System;
using Android.Support.V7.View.Menu;
using System.Threading;
using Android.Telephony;
using Android.Content.Res;

namespace MobileApp
{
    private WebView web_view;
    [Activity(Label = "@string/MobileApp", Theme = "@style/AppTheme", MainLauncher = true)]
    public class MainActivity : Activity
    {
        private Button mBtnSign;
        private object web_view;

        public void App()
        {
            MainPage = new NavigationPage(new resource.layout.Activity_main);
        }
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            Xamarin.Essentials.Platform.Init(this, savedInstanceState);
            // Set our view from the "main" layout resource
            SetContentView(Resource.Layout.activity_main);
            base.OnCreate(bundle);

            // Set our view from the "main" layout resource
            SetContentView(Resource.Layout.Main);

            web_view = FindViewById<WebView>(Resource.Id.webview);
            web_view.Settings.JavaScriptEnabled = true;
            web_view.SetWebViewClient(new HelloWebViewClient());
            web_view.LoadUrl("https://https://www.news24.com/");
            mBtnSign = FindViewId<Button>(Resource.Id.buttonSign);
            mBtnSign.Click += mBtnClick_Click;
        }

        private T FindViewId<T>(object buttonSign)
        {
            throw new NotImplementedException();
        }

        public override void OnRequestPermissionsResult(int requestCode, string[] permissions, [GeneratedEnum] Android.Content.PM.Permission[] grantResults)
        {
            Xamarin.Essentials.Platform.OnRequestPermissionsResult(requestCode, permissions, grantResults);

            base.OnRequestPermissionsResult(requestCode, permissions, grantResults);
            SetContentView(Resource.Layout.Splash_screen);
        }

        public class HelloWebViewClient : WebViewClient
        {
            public override bool ShouldOverrideUrlLoading(WebView view, string url)
            {
                view.LoadUrl(url);
                return false;
            }
            public override bool ShouldOverrideUrlLoading(WebView view, IWebResourceRequest request)
            {
                view.LoadUrl(request.Url.ToString());
                return false;
            }
        }
        async void mBtnClick_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
            FragmentTransaction transaction = FragmentManager.BeginTransaction();
            dialong_Sign_up sign = new dialong_Sign_up();
            dialong_Sign_up.Show(transaction, "dialog fragment");
            dialong_Sign_up.SignupFinish += diallongSign_SighnupFinsh;
            await Navigation.PushAsync(new Home());

        }c
        void diallongSign_SighnupFinsh(object sender, OnsignEventArg e)
        {
            Thread thread = new Thread;
            thread.Start();
        }
        private void ActlikeRequest()
        {
            Thread.Sleep(3000);
        }

    }
}
 