﻿namespace In
{
    internal class InfoData
    {
    }
}