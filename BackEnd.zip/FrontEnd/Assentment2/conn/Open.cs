﻿namespace conn
{
    internal class Open
    {
    }
}