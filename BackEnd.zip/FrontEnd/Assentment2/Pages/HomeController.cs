﻿using System;
using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;


namespace Assentment2.Pages
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            string connectStr = "Data Source=(localdb)'\'MSSQLLocalDB;Initial Catalog=Assement2;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
            SqlConnection conn = SqlConnection(connectStr);
            conn.Open();
            SqlCommand cmd = new SqlCommand("select i.Id, Name, Username, Password, [Address 1],[Address 2],City,[State/Province],Last_Login,Country,[Zip Code] from person p, info i where p.Id = i.[Person ID]")
            {
                Connection = conn
            };
            string temp = "";
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                temp += reader["i.Id"].ToString();
                temp += reader["Name"].ToString();
                temp += reader["Username"].ToString();
                temp += reader["Password"].ToString();
                temp += reader["Address 1"].ToString();
                temp += reader["Address 2"].ToString();
                temp += reader["City"].ToString();
                temp += reader["State/Province"].ToString();
                temp += reader["Last_Login"].ToString();
                temp += reader["Zip Code"].ToString();
                temp += reader["Country"].ToString();
                temp += "<br>";
            }
            conn.Close();
            ViewBag.HTMLContent = temp;
            return View("Index");
        }

        [HttpPost]
        public ActionResult Index(string Name, string Surname, string Username, string Password, string Addressone, string Addresstwo, string SP, string City, string Country, int Zip)
        {
            
            Person Per = new Person();
            Per.InsertData(Name, Surname, Username, Password);
            Info In = new Info();
            In.InfoData(Addressone, Addresstwo, SP, City, Country, Zip);
            return View("Index");
        }

        private SqlConnection SqlConnection(string connectStr)
        {
            throw new NotImplementedException();
        }
    }
        public class Person
        {
            private const string ConnectionString = "Data Source=(localdb)'\'MSSQLLocalDB;Initial Catalog=Assement2;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";

            public void InsertData(string Name, string Surname, string Username, string Password)
            {
                SqlConnection Con = new SqlConnection(ConnectionString);
                int Id = 0;
                string sql = "select count(id) + 1 as Total from Person";
                using (Con)
                {
                    SqlCommand cmd = new SqlCommand(sql, Con);
                    try
                    {
                        Con.Open();
                        Id = (int)cmd.ExecuteScalar();
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                    }
                }

                SqlCommand Cmd = new SqlCommand("insert into Person(Id,Name,Surname,Username,Password,Last_Login)" +
                "VALUES(@Id,@Name,@Surname,@Username,@Password,@LastLogin)", Con);
                Cmd.Parameters.Add("@Id", System.Data.SqlDbType.Int);
                Cmd.Parameters.Add("@Name", System.Data.SqlDbType.VarChar);
                Cmd.Parameters.Add("@Surname", System.Data.SqlDbType.VarChar);
                Cmd.Parameters.Add("@Username", System.Data.SqlDbType.VarChar);
                Cmd.Parameters.Add("@Password", System.Data.SqlDbType.VarChar);
                Cmd.Parameters.Add("@LastLogin", System.Data.SqlDbType.DateTime);
                Cmd.Parameters["@Id"].Value = Convert.ToInt32(Id);
                Cmd.Parameters["@Name"].Value = Convert.ToChar(Name);
                Cmd.Parameters["@Surname"].Value = Convert.ToChar(Surname);
                Cmd.Parameters["@Username"].Value = Convert.ToChar(Username);
                Cmd.Parameters["@Password"].Value = Convert.ToChar(Password);
                Cmd.Parameters["@LastLogin"].Value = DateTime.Now;
                Con.Open();
            _ = Cmd.ExecuteNonQuery();
                Con.Close();
            }
        }

        public class Info
        {
            private const string V = "Data Source=(localdb)'\'MSSQLLocalDB;Initial Catalog=Assement2;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";

            public void InfoData(string Addressone, string Addresstwo, string ST, string City, string Country, int Zip)
            {
                const string ConnectionString = V;
                SqlConnection Con = new SqlConnection(ConnectionString);
                int Id = 0;
                int personid = 0;
                string sql = "select count(id) as Total from Person";
                using (Con)
                {
                    SqlCommand cmd = new SqlCommand(sql, Con);

                    try
                    {
                        Con.Open();
                        Id = (int)cmd.ExecuteScalar();
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                    }
                    using (Con)
                    {
                        string sqltwo = "select id from Person where id = @PersonID";
                        SqlCommand cmdtwo = new SqlCommand(sqltwo, Con);
                        cmdtwo.Parameters.Add("@PersonID", System.Data.SqlDbType.Int);
                        try
                        {
                            Con.Open();
                            personid = (int)cmdtwo.ExecuteScalar();
                        }
                        catch (Exception ex2)
                        {
                            Console.WriteLine(ex2.Message);
                        }
                    }
                }

                SqlCommand Cmdthree = new SqlCommand("insert into info(Id,[Address 1],[Address 2],City,[State/Province],Country,[Zip Code],[Person ID])" +
                "VALUES(@Id,@Addressone,@Addresstwo,@City,@SP,@Country,@Zip,@PersonID)", Con);
                Cmdthree.Parameters.Add("@Id", System.Data.SqlDbType.Int);
                Cmdthree.Parameters.Add("@Addressone", System.Data.SqlDbType.VarChar);
                Cmdthree.Parameters.Add("@Addresstwo", System.Data.SqlDbType.VarChar);
                Cmdthree.Parameters.Add("@City", System.Data.SqlDbType.VarChar);
                Cmdthree.Parameters.Add("@SP", System.Data.SqlDbType.VarChar);
                Cmdthree.Parameters.Add("@Country", System.Data.SqlDbType.VarChar);
                Cmdthree.Parameters.Add("@Zip", System.Data.SqlDbType.Int);
                Cmdthree.Parameters.Add("@PersonID", System.Data.SqlDbType.Int);
                Cmdthree.Parameters["@Id"].Value = Convert.ToInt32(Id);
                Cmdthree.Parameters["@Addressone"].Value = Convert.ToChar(Addressone);
                Cmdthree.Parameters["@Addresstwo"].Value = Convert.ToChar(Addresstwo);
                Cmdthree.Parameters["@City"].Value = Convert.ToChar(City);
                Cmdthree.Parameters["@SP"].Value = Convert.ToChar(ST);
                Cmdthree.Parameters["@Country"].Value = Convert.ToChar(Country);
                Cmdthree.Parameters["@Zip"].Value = Convert.ToInt32(Zip);
                Cmdthree.Parameters["@PersonID"].Value = Convert.ToInt32(personid);
                Con.Open();
            _ = Cmdthree.ExecuteNonQuery();
            Con.Close();
            }

        }
    }

