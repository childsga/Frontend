﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Http;
using System.Data.SqlClient;
using System.Net.Mime;
using System.Net;
using System.Net.Http;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace Assentment2.Pages
{
    public class IndexModel : PerInfo
    {

    }

    
}