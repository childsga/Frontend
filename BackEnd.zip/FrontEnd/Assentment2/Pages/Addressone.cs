﻿namespace Assentment2.Person
{
    internal class Addressone
    {
    }
}