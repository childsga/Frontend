﻿namespace Assentment2.Pages
{
    public class PerInfo
    {
    }
}