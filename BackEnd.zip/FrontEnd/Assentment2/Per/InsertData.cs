﻿namespace Per
{
    internal class InsertData
    {
    }
}