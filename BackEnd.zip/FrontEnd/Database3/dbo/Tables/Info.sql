﻿CREATE TABLE [dbo].[Info] (
    [Id]             INT             NOT NULL,
    [Address 1]      VARCHAR (MAX)   NOT NULL,
    [Address 2]      VARBINARY (MAX) NOT NULL,
    [City]           VARCHAR (50)    NOT NULL,
    [State/Province] VARCHAR (50)    NOT NULL,
    [Country]        VARBINARY (MAX) NOT NULL,
    [Zip Code]       INT             NOT NULL,
    [Person ID]      INT             NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);


GO
ALTER TABLE [dbo].[Info] WITH NOCHECK
    ADD CONSTRAINT [FK_Info_ToTable] FOREIGN KEY ([Person ID]) REFERENCES [dbo].[Person] ([Id]);
GO

ALTER TABLE [dbo].[Info] WITH CHECK CHECK CONSTRAINT [FK_Info_ToTable];