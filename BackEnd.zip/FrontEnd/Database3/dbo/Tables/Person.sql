﻿CREATE TABLE [dbo].[Person] (
    [Id]         INT           NOT NULL,
    [Name]       VARCHAR (MAX) NOT NULL,
    [Surname]    VARCHAR (MAX) NOT NULL,
    [Username]   VARCHAR (50)  NOT NULL,
    [Password]   VARCHAR (50)  NOT NULL,
    [Last Login] DATETIME2 (7) NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

