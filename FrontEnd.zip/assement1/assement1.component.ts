import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-assement1',
  templateUrl: './assement1.component.html',
  styleUrls: ['./assement1.component.css']
})
export class Assement1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
