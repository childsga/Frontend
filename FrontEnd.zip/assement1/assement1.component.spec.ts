import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Assement1Component } from './assement1.component';

describe('Assement1Component', () => {
  let component: Assement1Component;
  let fixture: ComponentFixture<Assement1Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Assement1Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(Assement1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
